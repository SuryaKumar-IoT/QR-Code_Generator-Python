#####################
Setup for development
#####################

Clone the git repository using ``git clone https://github.com/ojii/pymaging.git``.

To run the tests, simply execute ``setup.py test`` with a Python version of your choice, or run ``./runtests.sh`` to run
it against all installed (and supported) Python versions.
