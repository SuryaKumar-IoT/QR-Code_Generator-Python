########
pymaging
########

Pure Python imaging library.

* Author: Jonas Obrist and https://github.com/ojii/pymaging/contributors
* License: BSD (some files have other licenses, see LICENSE.txt)
* Compatibility: Python 2.6, 2.7, 3.1, 3.2 and PyPy 1.8.
* Requirements: distribute
* Docs: http://pymaging.rtfd.org

Thanks to @katylava for helping me pick the name
